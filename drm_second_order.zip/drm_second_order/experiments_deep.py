import subprocess
import time

config = {
    "CartPole-v1": {
        'alpha': '5000',
        'num-updates': '100',
        'max-timesteps': '500',  # horizon
        'batch-size': '200',
        'hidden-sizes': '()',  # linear features ONLY
    },

    "Reacher-v4": {
        'alpha': '100000000',
        'num-updates': '100',
        'max-timesteps': '50',  # horizon
        'batch-size': '200',
        'hidden-sizes': '(32, 32)',
    },

    "Humanoid-v4": {
        'alpha': '100000',
        'num-updates': '100',
        'max-timesteps': '1000',  # horizon
        'batch-size': '200',
        'hidden-sizes': '(64, 64)',
    },

    "HalfCheetah-v4": {
        'alpha': '1000000',
        'num-updates': '100',
        'max-timesteps': '1000',  # horizon
        'batch-size': '200',
        'hidden-sizes': '(400, 300)',
    }
}

if __name__ == "__main__":

    NUM_SIMULATIONS = 10
    ENV = "CartPole-v1"
    env_config = config[ENV]

    f_labels = ['YE', 'GE', 'BE',  'RE']
    f_list = ['1 - (1-x)**1.', 'x - x**2', '1 - (1-x)**2', 'torch.exp(-(-torch.log(x)) ** .5)']

    for ALGO in ['drm_acrpn']:  # {reinforce, acrpn, vracrpn}

        for lab, f in zip(f_labels[1:3], f_list[1:3]):
            print(lab, f)

            t_ = time.time()

            for s in range(NUM_SIMULATIONS):

                print(f"SIMULATION NO : {s + 1}", end="\n")

                command = [
                    'python',
                    f'deep/{ALGO}.py',
                    '--exp-name', f'BASELINE2{s + 1}_{lab}0',
                    '--env-seed', '-1',
                    '--save', 'True',  # change to True if you want to save simulation data.
                    '--track', 'False',
                    '--alpha', env_config['alpha'],
                    '--normalize-returns', 'False',
                    '--drm-function', "lambda x: " + f,
                    '--num-updates', env_config['num-updates'],
                    '--max-timesteps', env_config['max-timesteps'],
                    '--gym-id', ENV,
                    '--hidden-sizes', env_config['hidden-sizes'],
                    '--batch-size', env_config['batch-size']
                ]

                subprocess.run(command)

            print("Simulations complete. Time taken:", round(time.time() - t_, 3))
